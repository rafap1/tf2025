This module creates a simple web server

Module for illustration of module location within a project