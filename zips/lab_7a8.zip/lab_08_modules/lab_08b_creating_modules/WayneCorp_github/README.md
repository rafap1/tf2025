## Lab 08b - Creating Modules - github version

Here we repeat the "WayneCorp" exercise, but this time the TF code of the modules is in a github repo, instead of a local path.

github is one example of Terraform module sources, as documented in 
https://developer.hashicorp.com/terraform/language/modules/sources



