Lab Terraform Modules - Example 1

Version with module in local storage